package co.com.valid.test.modelDAO;

import java.util.List;

import co.com.valid.test.model.Person;

public interface IPerson {

	public List<Person> list();

	public Person listById(int id);

	public int addPerson(Person p);

	public int editPerson(Person p);

	public int deletePerson(int id);
	
	public int processPerson(int id);
}
