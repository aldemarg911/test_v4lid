package co.com.valid.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import co.com.valid.test.model.Person;
import co.com.valid.test.service.IPersonService;

@Controller
public class PersonController {
	
	@Autowired
	private IPersonService service;
	
	@RequestMapping("/showPerson")
	public String list(Model model) {
		
		List<Person> lstPerson = service.listRest();		
		
		model.addAttribute("lstPersonas", lstPerson);
		
		return "listarPersona";
	}

	
	@GetMapping("/newPerson")
	public String crear() {		
		
		return "crearPersona";
	}
	
	@PostMapping("/addPerson")
	public String agregar(@Validated Person p) {
		
		service.addPersonRest(p);
		return "redirect:/showPerson";
	}

	@PostMapping("/deletePerson")
	public String borraPersona(Model model, @RequestParam(value="chkPerson") ArrayList<String> chkPerson) {

				
		for(String value: chkPerson) {
			int del = service.deletePersonRest(Integer.parseInt(value));
		}
		
		return "redirect:/showPerson";
	}
	
	
	@RequestMapping("/processPerson")
	public String procesaPersona(Model model, @RequestParam(value="chkPerson") ArrayList<String> chkPerson) {

				
		for(String value: chkPerson) {
			int del = service.processPersonRest(Integer.parseInt(value));
		}
		
		return "redirect:/showPerson";
	}

}
