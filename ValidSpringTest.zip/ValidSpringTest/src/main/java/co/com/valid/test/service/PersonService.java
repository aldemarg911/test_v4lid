package co.com.valid.test.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import co.com.valid.test.model.Person;
import co.com.valid.test.modelDAO.IPerson;

@Service
public class PersonService implements IPersonService{
	
	private final RestTemplate restTemplate = new RestTemplate();

	@Autowired
	private IPerson dao;
	
	@Override
	public List<Person> list() {
		// TODO Auto-generated method stub
		return dao.list();
	}

	@Override
	public Person listById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addPerson(Person p) {
		
		dao.addPerson(p);
		
		return 0;
	}

	@Override
	public int editPerson(Person p) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deletePerson(int id) {
		// TODO Auto-generated method stub
		int res = dao.deletePerson(id);
		return res;
	}
	
	
	@Override
	public int processPerson(int id) {
		// TODO Auto-generated method stub
		int res = dao.processPerson(id);
		return res;
	}
	
	
	@Override
	public int addPersonRest(Person p) {
		
		Integer response = restTemplate.postForObject("http://localhost:8181/addPersonREST",p, Integer.class);
		
		return response.intValue();
	}
	
	
	@Override
	public List<Person> listRest() {
		
		
		ResponseEntity<Person[]> response = restTemplate.getForEntity("http://localhost:8181/showPersonREST", Person[].class);
		
		Person[] personas = response.getBody();
		List<Person> lstPerson = new ArrayList<Person>();
		
		for (int i = 0; i < personas.length; i++) {
			lstPerson.add(personas[i]);
		}
		
		return lstPerson;
	}
	
	@Override
	public int deletePersonRest(int id) {
		
		Integer response = restTemplate.getForObject("http://localhost:8181/deletePersonREST/"+id, Integer.class);
		
		return response.intValue();
	}


	@Override
	public int processPersonRest(int id) {
		
		Integer response = restTemplate.getForObject("http://localhost:8181/processPersonREST/"+id, Integer.class);
		
		return response.intValue();
	}
	

}
