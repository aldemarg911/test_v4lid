package co.com.valid.test.model;

import org.springframework.lang.NonNull;

public class Person {
	
	private int id;
	
	
	private String name;
	
	
	private String apellido;
	
	private boolean procesado;
	
	public Person() {
		// TODO Auto-generated constructor stub
	}
	

	
	public Person(int id, String name, String apellido, boolean procesado) {
		super();
		this.id = id;
		this.name = name;
		this.apellido = apellido;
		this.procesado = procesado;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public boolean isProcesado() {
		return procesado;
	}

	public void setProcesado(boolean procesado) {
		this.procesado = procesado;
	}

}
