package co.com.valid.test.modelDAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import co.com.valid.test.model.Person;

@Repository
public class PersonDAO implements IPerson {

	@Autowired
	private JdbcTemplate template;
	
	@Override
	public List<Person> list() {
		// TODO Auto-generated method stub
		String sql = "select * from person";
		List<Person> personas = template.query(sql, new BeanPropertyRowMapper<Person>(Person.class));
		return personas;
	}

	@Override
	public Person listById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addPerson(Person p) {
		String sql = "insert into person(name, apellido, procesado) values (?, ?, ?)";
		int res = template.update(sql, p.getName(), p.getApellido(), false);
		
		return res;
	}

	@Override
	public int editPerson(Person p) {
		
		String sql = "insert into person(name, apellido, procesado) values (?, ?, ?)";
		int res = template.update(sql, p.getName(), p.getApellido(), false);
		
		return res;
	}

	@Override
	public int deletePerson(int id) {
		String sql = "delete from person where id=?";
		int res = template.update(sql, id);
		return res;
	}

	@Override
	public int processPerson(int id) {
		String sql = "update person set procesado = true where id=?";
		int res = template.update(sql, id);
		return res;
	}

}
