package co.com.valid.test.service;

import java.util.List;

import co.com.valid.test.model.Person;

public interface IPersonService {

	public List<Person> list();

	public Person listById(int id);

	public int addPerson(Person p);

	public int editPerson(Person p);

	public int deletePerson(int id);
	
	public int processPerson(int id);
	
	// REST Services, pueden estar en el proyecto que consuma los Servicios / Implementación
	
	public int addPersonRest(Person p);
	
	public List<Person> listRest();
	
	public int deletePersonRest(int id);
	
	public int processPersonRest(int id);

}
