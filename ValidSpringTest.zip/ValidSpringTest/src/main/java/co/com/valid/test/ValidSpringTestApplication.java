package co.com.valid.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
public class ValidSpringTestApplication implements CommandLineRunner{

	@Autowired
	private JdbcTemplate template;
	
	public static void main(String[] args) {
		SpringApplication.run(ValidSpringTestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		template.execute("DROP TABLE PERSON IF EXISTS");
		template.execute("CREATE TABLE PERSON ("
				+ "id INTEGER(11) PRIMARY KEY auto_increment, "
				+ "name VARCHAR(255), "
				+ "apellido VARCHAR(255),"
				+ "procesado BOOLEAN) ");
		
		
		template.update("INSERT INTO PERSON(name, apellido, procesado) VALUES ('HUGO ALDEMAR', 'GOMEZ MARTINEZ', FALSE)");
		template.update("INSERT INTO PERSON(name, apellido, procesado) VALUES ('DANIEL LEONARDO', 'PEREZ RUIZ', FALSE)");
		template.update("INSERT INTO PERSON(name, apellido, procesado) VALUES ('MARIA LUISA', 'DIAZ FRANCO', FALSE)");
				
		
	}

}
