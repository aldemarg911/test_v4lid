package co.com.valid.test.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.valid.test.model.Person;
import co.com.valid.test.service.IPersonService;

@RestController
public class PersonResource {
	
	@Autowired
	private IPersonService service;
	
	@RequestMapping("/addPersonREST")
	public int createPerson(@RequestBody Person p) {
		
		return service.addPerson(p);
	}
	
	@RequestMapping("/showPersonREST")
	public List<Person> list() {
		
		return service.list();
	}
	
	@RequestMapping("/deletePersonREST/{id}")
	public int remove(@PathVariable("id") int id) {		
		int del = service.deletePerson(id);
		return del;
	}
	
	@RequestMapping("/processPersonREST/{id}")
	public int process(@PathVariable("id") int id) {		
		int del = service.processPerson(id);
		return del;
	}
	

	
}
